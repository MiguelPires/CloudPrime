JAVA_HOME=/etc/alternatives/java_sdk_1.7.0
JAVA_ROOT=/etc/alternatives/java_sdk_1.7.0
JDK_HOME=/etc/alternatives/java_sdk_1.7.0
JRE_HOME=/etc/alternatives/java_sdk_1.7.0/jre
PATH=/etc/alternatives/java_sdk_1.7.0/bin:$PATH
SDK_HOME=/etc/alternatives/java_sdk_1.7.0
